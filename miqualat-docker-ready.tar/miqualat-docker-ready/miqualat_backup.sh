#!/bin/bash
#
# crea un backup completo dei files e del database MIQUALAT
#
#
# 1. backup dei files
#
zip -r  /home/miqualat/BACKUP_FOLDER/MIQUALAT_FULL_backup_$(date +"%d%m%Y_%H%M").zip /home/miqualat/miqualat-docker/
#
# 2. backup completo del database MIQUALAT
#
docker exec bb6350164498 sh -c 'exec mysqldump --all-databases -uroot -pnNFB6V76zqrDdssCzxsbJvSFBf22UyNW' >  /home/miqualat/BACKUP_FOLDER/MIQUALAT_FULL_backup_$(date +"%d%m%Y_%H%M").sql
#
# !!! ripristino del db !!!
#
# docker exec [container_id] sh -c 'exec mysql --all-databases -uroot -pPASSWORD' < DB-full-backup.sql
#
#
# END
