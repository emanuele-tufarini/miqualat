---
Read this README for make a docker compose services of miqualat with a single command.
Go to the "miqualat-docker" folder and run the docker compose services with the command "docker-compose up".
Use the "miqualat_backup.sh" bash file to set up a backup with cronjob, use the command "cronjob -e" for repeat a job periodically with this utility you can run a command or a shell file.
The "miqualat_backup.sh" bash file make a full backup of files and database at 00:00 of every day.
---